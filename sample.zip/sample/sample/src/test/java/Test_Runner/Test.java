package Test_Runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="C:\\Users\\Shikhar.dubey\\Downloads\\sample\\sample\\src\\main\\java\\Features\\Test.feature",
		glue="Step_Defination",
		dryRun=false,
		monochrome=true,
		plugin= {"pretty","html:test-output"}		
		)


public class Test {

}
