package page_object;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Object1 {

	WebDriver ldriver;
	public Object1(WebDriver rdriver) {
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//input[@id='Email']")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="//input[@id='Password']")
	@CacheLookup
	WebElement pass;
	
	public void user(String uname) {
		email.clear();
		email.sendKeys(uname);
	}
	
	public void password(String passw) {
	pass.clear();
		pass.sendKeys(passw);
	}
	
}
