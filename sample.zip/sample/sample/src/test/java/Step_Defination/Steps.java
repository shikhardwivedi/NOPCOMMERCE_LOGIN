package Step_Defination;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page_object.Object1;

public class Steps {
	
	
	
	WebDriver driver;
	Object1 ob;
	
	@Given("User Launch chrome browser")
	public void user_Launch_chrome_browser() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+".//Drivers//chromedriver.exe");
		driver=new ChromeDriver();
		ob=new Object1(driver);
	}

	@Given("User open url {string}")
	public void user_open_url(String string) {
	   driver.manage().window().maximize();
	   driver.get(string);

	}

	@When("User enter the user name and password")
	public void user_enter_the_user_name_and_password() throws IOException {
		File file=new File("C:\\Users\\Shikhar.dubey\\Downloads\\sample\\sample\\Excel\\Testing.xlsx");
		FileInputStream inputstream=new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(inputstream);
        XSSFSheet sheet=wb.getSheet("Login_Details");
    
        XSSFRow row=sheet.getRow(1);
        XSSFCell cell=row.getCell(0);
        String Username=cell.getStringCellValue();
        ob.user(Username);
        
        XSSFRow row1=sheet.getRow(1);
        XSSFCell cell1=row1.getCell(1);
        String password1=cell1.getStringCellValue();
        ob.password(password1);
        
	
	}

	@When("User click on the login button")
	public void user_click_on_the_login_button() throws Exception {
	  driver.findElement(By.xpath("//button[@class='button-1 login-button']")).click();
	  Thread.sleep(1000);
	}

	@Then("User close web broser")
	public void user_close_web_broser() {
	    driver.close();
	}
	
	
	
}
